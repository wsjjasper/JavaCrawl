package com.xs.ai.data;

public enum BookingStatus {

	CONFIRMED, COMPLETED, CANCELLED

}
