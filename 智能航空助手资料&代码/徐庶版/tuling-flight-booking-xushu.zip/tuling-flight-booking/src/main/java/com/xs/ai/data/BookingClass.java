package com.xs.ai.data;

public enum BookingClass {

	ECONOMY, PREMIUM_ECONOMY, BUSINESS

}
